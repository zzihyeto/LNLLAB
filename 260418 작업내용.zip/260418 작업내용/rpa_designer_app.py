import streamlit as st
import json
import re
import zipfile
import io
import uuid
from datetime import datetime
import anthropic

# ============================================================
# Claude API 시스템 프롬프트 — JSON만 반환
# ============================================================
SYSTEM_PROMPT = """당신은 UiPath RPA 프로세스 설계 전문가입니다.
사용자가 입력한 프로세스 정의서를 분석하여 아래 JSON 형식으로만 응답합니다.
절대 XML이나 XAML을 직접 작성하지 않습니다. JSON만 출력합니다.

## 응답 형식 (반드시 준수)

정보가 부족하거나 모호한 경우:
[QUESTION]
{
  "question": "질문 내용",
  "partial": { ... 지금까지 확정된 JSON ... }
}
[/QUESTION]

모든 정보가 확보된 경우:
[DONE]
{
  "process_name": "영문PascalCase프로세스명",
  "display_name": "한국어 프로세스명",
  "arguments": [
    {"name": "in_변수명", "type": "x:String", "direction": "In"}
  ],
  "variables": [
    {"name": "변수명", "type": "x:String", "default": "\"\""}
  ],
  "steps": [
    {"type": "log", "display_name": "시작 로그", "level": "Info", "message": "프로세스 시작"},
    {"type": "click", "display_name": "로그인 버튼 클릭"},
    {"type": "type", "display_name": "아이디 입력", "text": "[in_userId]"},
    {"type": "assign", "display_name": "변수 초기화", "var_name": "변수명", "var_type": "x:String", "value": "\"\""},
    {"type": "if", "display_name": "조건 확인", "condition": "[조건식]",
      "then_steps": [ ... ],
      "else_steps": [ ... ]
    },
    {"type": "foreach", "display_name": "반복 처리", "type_arg": "x:String", "var_name": "item",
      "body_steps": [ ... ]
    }
  ],
  "error_steps": [
    {"type": "log", "display_name": "오류 로그", "level": "Error", "message": "[exception.Message]"}
  ]
}
[/DONE]

## 규칙
- step type은 반드시 log / click / type / assign / if / foreach 중 하나만 사용합니다.
- arguments name은 반드시 in_ 또는 out_ 접두사를 사용합니다.
- variables name은 camelCase 영문을 사용합니다.
- message 값에서 따옴표는 반드시 \\"로 이스케이프합니다.
- 항상 한국어로 답변합니다.
- JSON 외 다른 텍스트는 출력하지 않습니다."""


# ============================================================
# 검증된 XAML 템플릿 함수들 (샘플 파일 기반 — 수정 금지)
# ============================================================

COMMON_NAMESPACES = """xmlns="http://schemas.microsoft.com/netfx/2009/xaml/activities"
  xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
  xmlns:sap="http://schemas.microsoft.com/netfx/2009/xaml/activities/presentation"
  xmlns:sap2010="http://schemas.microsoft.com/netfx/2010/xaml/activities/presentation"
  xmlns:scg="clr-namespace:System.Collections.Generic;assembly=System.Private.CoreLib"
  xmlns:sco="clr-namespace:System.Collections.ObjectModel;assembly=System.Private.CoreLib"
  xmlns:ui="http://schemas.uipath.com/workflow/activities"
  xmlns:uix="http://schemas.uipath.com/workflow/activities/uix"
  xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" """

COMMON_NS_IMPL = """    <sco:Collection x:TypeArguments="x:String">
      <x:String>System.Activities</x:String>
      <x:String>System.Activities.Statements</x:String>
      <x:String>System.Activities.Expressions</x:String>
      <x:String>System.Activities.Validation</x:String>
      <x:String>System.Activities.XamlIntegration</x:String>
      <x:String>Microsoft.VisualBasic</x:String>
      <x:String>Microsoft.VisualBasic.Activities</x:String>
      <x:String>System</x:String>
      <x:String>System.Collections</x:String>
      <x:String>System.Collections.Generic</x:String>
      <x:String>System.Collections.ObjectModel</x:String>
      <x:String>System.Data</x:String>
      <x:String>System.Diagnostics</x:String>
      <x:String>System.Drawing</x:String>
      <x:String>System.IO</x:String>
      <x:String>System.Linq</x:String>
      <x:String>System.Net.Mail</x:String>
      <x:String>System.Xml</x:String>
      <x:String>System.Xml.Linq</x:String>
      <x:String>UiPath.Core</x:String>
      <x:String>UiPath.Core.Activities</x:String>
      <x:String>UiPath.UIAutomationNext.Enums</x:String>
      <x:String>UiPath.UIAutomationNext.Models</x:String>
      <x:String>UiPath.UIAutomationNext.Activities</x:String>
    </sco:Collection>"""

COMMON_REF_IMPL = """    <sco:Collection x:TypeArguments="AssemblyReference">
      <AssemblyReference>Microsoft.VisualBasic</AssemblyReference>
      <AssemblyReference>mscorlib</AssemblyReference>
      <AssemblyReference>System</AssemblyReference>
      <AssemblyReference>System.Activities</AssemblyReference>
      <AssemblyReference>System.ComponentModel.TypeConverter</AssemblyReference>
      <AssemblyReference>System.Core</AssemblyReference>
      <AssemblyReference>System.Data</AssemblyReference>
      <AssemblyReference>System.Data.Common</AssemblyReference>
      <AssemblyReference>System.Linq</AssemblyReference>
      <AssemblyReference>System.Net.Mail</AssemblyReference>
      <AssemblyReference>System.ObjectModel</AssemblyReference>
      <AssemblyReference>System.Private.CoreLib</AssemblyReference>
      <AssemblyReference>System.Xaml</AssemblyReference>
      <AssemblyReference>System.Xml</AssemblyReference>
      <AssemblyReference>UiPath.System.Activities</AssemblyReference>
      <AssemblyReference>UiPath.UiAutomation.Activities</AssemblyReference>
      <AssemblyReference>UiPath.Studio.Constants</AssemblyReference>
      <AssemblyReference>UiPath.UIAutomationNext</AssemblyReference>
      <AssemblyReference>UiPath.UIAutomationCore</AssemblyReference>
      <AssemblyReference>UiPath.UIAutomationNext.Activities</AssemblyReference>
      <AssemblyReference>UiPath.Platform</AssemblyReference>
      <AssemblyReference>System.Security.Permissions</AssemblyReference>
      <AssemblyReference>PresentationFramework</AssemblyReference>
      <AssemblyReference>WindowsBase</AssemblyReference>
      <AssemblyReference>System.Collections</AssemblyReference>
      <AssemblyReference>System.Linq.Expressions</AssemblyReference>
      <AssemblyReference>UiPath.System.Activities.Design</AssemblyReference>
    </sco:Collection>"""


class Counter:
    """액티비티 IdRef 순번 카운터"""
    def __init__(self):
        self._counts = {}

    def next(self, prefix: str) -> str:
        self._counts[prefix] = self._counts.get(prefix, 0) + 1
        return f"{prefix}_{self._counts[prefix]}"


def xe(v: str) -> str:
    """XML 속성값 이스케이프 — &, ", <, > 처리"""
    return v.replace("&", "&amp;").replace('"', "&quot;").replace("<", "&lt;").replace(">", "&gt;")


def xaml_log(display_name: str, ref_id: str, level: str, message: str) -> str:
    msg = message.strip()
    if msg.startswith("[") and msg.endswith("]"):
        # VB 표현식 — 안의 날따옴표만 &quot;로 교체
        inner = msg[1:-1].replace('"', "&quot;")
        msg_expr = f"[{inner}]"
    else:
        # 일반 문자열 — 날따옴표 &quot;로 교체
        clean = msg.replace('"', "&quot;")
        msg_expr = f'[&quot;{clean}&quot;]'
    return f"""          <ui:LogMessage DisplayName="{xe(display_name)}"
            sap:VirtualizedContainerService.HintSize="382,168"
            sap2010:WorkflowViewState.IdRef="{ref_id}"
            Level="{level}"
            Message="{msg_expr}" />"""

def xaml_click(display_name: str, ref_id: str) -> str:
    return f"""          <uix:NClick ActivateBefore="True" ClickType="Single"
            DisplayName="{xe(display_name)} (Selector 직접 지정 필요)"
            HealingAgentBehavior="SameAsCard"
            sap:VirtualizedContainerService.HintSize="382,232"
            sap2010:WorkflowViewState.IdRef="{ref_id}"
            KeyModifiers="None" MouseButton="Left" Version="V4">
            <uix:NClick.VerifyOptions>
              <uix:VerifyExecutionOptions DisplayName="{{x:Null}}" Mode="Appears">
                <uix:VerifyExecutionOptions.Retry>
                  <InArgument x:TypeArguments="x:Boolean" />
                </uix:VerifyExecutionOptions.Retry>
                <uix:VerifyExecutionOptions.Timeout>
                  <InArgument x:TypeArguments="x:Double" />
                </uix:VerifyExecutionOptions.Timeout>
              </uix:VerifyExecutionOptions>
            </uix:NClick.VerifyOptions>
          </uix:NClick>"""


def xaml_type(display_name: str, ref_id: str, text: str) -> str:
    return f"""          <uix:NTypeInto ActivateBefore="True" ClickBeforeMode="Single"
            ClipboardMode="Never"
            DisplayName="{xe(display_name)} (Selector 직접 지정 필요)"
            EmptyFieldMode="SingleLine"
            HealingAgentBehavior="SameAsCard"
            sap:VirtualizedContainerService.HintSize="382,293"
            sap2010:WorkflowViewState.IdRef="{ref_id}"
            Text="{text}" Version="V4">
            <uix:NTypeInto.VerifyOptions>
              <uix:VerifyExecutionTypeIntoOptions DisplayName="{{x:Null}}" Mode="Appears">
                <uix:VerifyExecutionTypeIntoOptions.Retry>
                  <InArgument x:TypeArguments="x:Boolean" />
                </uix:VerifyExecutionTypeIntoOptions.Retry>
                <uix:VerifyExecutionTypeIntoOptions.Timeout>
                  <InArgument x:TypeArguments="x:Double" />
                </uix:VerifyExecutionTypeIntoOptions.Timeout>
              </uix:VerifyExecutionTypeIntoOptions>
            </uix:NTypeInto.VerifyOptions>
          </uix:NTypeInto>"""


def xaml_assign(display_name: str, ref_id: str, var_name: str, var_type: str, value: str) -> str:
    val = value.strip()
    if val.startswith("[") and val.endswith("]"):
        # VB 표현식 — 안의 날따옴표 &quot;로 교체
        inner = val[1:-1].replace('"', "&quot;")
        safe_value = f"[{inner}]"
    else:
        # 문자열 리터럴 — 앞뒤 따옴표 제거 후 &quot;로 감쌈
        clean = val.strip('"').replace('"', "&quot;")
        safe_value = f"&quot;{clean}&quot;"
    return f"""          <Assign DisplayName="{xe(display_name)}"
            sap:VirtualizedContainerService.HintSize="382,57"
            sap2010:WorkflowViewState.IdRef="{ref_id}">
            <Assign.To>
              <OutArgument x:TypeArguments="{var_type}">[{var_name}]</OutArgument>
            </Assign.To>
            <Assign.Value>
              <InArgument x:TypeArguments="{var_type}">{safe_value}</InArgument>
            </Assign.Value>
          </Assign>"""

def xaml_if(display_name: str, ref_id: str, condition: str, then_xml: str, else_xml: str) -> str:
    then_block = f"""          <If.Then>
            <Sequence DisplayName="True 처리"
              sap:VirtualizedContainerService.HintSize="382,100"
              sap2010:WorkflowViewState.IdRef="{ref_id}_Then">
{then_xml}
            </Sequence>
          </If.Then>""" if then_xml.strip() else ""

    else_block = f"""          <If.Else>
            <Sequence DisplayName="False 처리"
              sap:VirtualizedContainerService.HintSize="382,100"
              sap2010:WorkflowViewState.IdRef="{ref_id}_Else">
{else_xml}
            </Sequence>
          </If.Else>""" if else_xml.strip() else ""

    return f"""          <If DisplayName="{xe(display_name)}"
            sap:VirtualizedContainerService.HintSize="382,100"
            sap2010:WorkflowViewState.IdRef="{ref_id}"
            Condition="{xe(condition)}">
{then_block}
{else_block}
          </If>"""


def xaml_foreach(display_name: str, ref_id: str, type_arg: str, var_name: str, body_xml: str) -> str:
    return f"""          <ForEach x:TypeArguments="{type_arg}" DisplayName="{xe(display_name)}"
            sap:VirtualizedContainerService.HintSize="382,100"
            sap2010:WorkflowViewState.IdRef="{ref_id}">
            <ActivityAction x:TypeArguments="{type_arg}">
              <ActivityAction.Argument>
                <DelegateInArgument x:TypeArguments="{type_arg}" Name="{var_name}" />
              </ActivityAction.Argument>
              <Sequence DisplayName="반복 처리"
                sap:VirtualizedContainerService.HintSize="382,100"
                sap2010:WorkflowViewState.IdRef="{ref_id}_Body">
{body_xml}
              </Sequence>
            </ActivityAction>
          </ForEach>"""


def steps_to_xaml(steps: list, counter: Counter, indent: str = "          ") -> str:
    """JSON steps 배열을 XAML 액티비티 문자열로 변환"""
    lines = []
    for step in steps:
        t = step.get("type", "")
        dn = step.get("display_name", "액티비티")

        if t == "log":
            ref = counter.next("LogMessage")
            lines.append(xaml_log(dn, ref, step.get("level", "Info"), step.get("message", "")))

        elif t == "click":
            ref = counter.next("NClick")
            lines.append(xaml_click(dn, ref))

        elif t == "type":
            ref = counter.next("NTypeInto")
            lines.append(xaml_type(dn, ref, step.get("text", "")))

        elif t == "assign":
            ref = counter.next("Assign")
            lines.append(xaml_assign(
                dn, ref,
                step.get("var_name", "var"),
                step.get("var_type", "x:String"),
                step.get("value", "&quot;&quot;")
            ))

        elif t == "if":
            ref = counter.next("If")
            then_xml = steps_to_xaml(step.get("then_steps", []), counter)
            else_xml = steps_to_xaml(step.get("else_steps", []), counter)
            lines.append(xaml_if(dn, ref, step.get("condition", "[True]"), then_xml, else_xml))

        elif t == "foreach":
            ref = counter.next("ForEach")
            body_xml = steps_to_xaml(step.get("body_steps", []), counter)
            lines.append(xaml_foreach(
                dn, ref,
                step.get("type_arg", "x:String"),
                step.get("var_name", "item"),
                body_xml
            ))

    return "\n".join(lines)


def build_xaml(data: dict) -> str:
    """JSON 설계 → Main.xaml 생성"""
    counter = Counter()
    process_name = data.get("process_name", "MyProcess")

    # 인자 선언
    args_xml = "\n".join([
        f'    <x:Property Name="{a["name"]}" Type="{a["direction"]}Argument({a["type"]})" />'
        for a in data.get("arguments", [])
    ])

    # 변수 선언
    def esc_default(val: str) -> str:
        """Variable Default 속성값 이스케이프"""
        # 이미 &quot; 처리된 경우 중복 방지 후 재처리
        clean = val.replace("&quot;", '\"').replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
        return clean.replace("&", "&amp;").replace('\"', "&quot;").replace("<", "&lt;").replace(">", "&gt;")

    vars_xml = "\n".join([
        f'      <Variable x:TypeArguments="{v["type"]}" Name="{v["name"]}" Default="{esc_default(v.get("default", ""))}" />'
        for v in data.get("variables", [])
    ])

    # 메인 액티비티
    main_xml = steps_to_xaml(data.get("steps", []), counter)

    # 오류 처리 액티비티
    error_xml = steps_to_xaml(data.get("error_steps", [
        {"type": "log", "display_name": "오류 로그", "level": "Error", "message": "[exception.Message]"}
    ]), counter)

    members_block = f"  <x:Members>\n{args_xml}\n  </x:Members>" if args_xml.strip() else ""
    vars_block = f"    <Sequence.Variables>\n{vars_xml}\n    </Sequence.Variables>" if vars_xml.strip() else ""

    return f"""<?xml version="1.0" encoding="utf-8"?>
<Activity mc:Ignorable="sap sap2010"
  x:Class="{process_name}"
  {COMMON_NAMESPACES}>
{members_block}
  <TextExpression.NamespacesForImplementation>
{COMMON_NS_IMPL}
  </TextExpression.NamespacesForImplementation>
  <TextExpression.ReferencesForImplementation>
{COMMON_REF_IMPL}
  </TextExpression.ReferencesForImplementation>
  <Sequence DisplayName="{data.get("display_name", process_name)}"
    sap:VirtualizedContainerService.HintSize="929,600"
    sap2010:WorkflowViewState.IdRef="Sequence_Main">
{vars_block}
    <TryCatch DisplayName="메인 프로세스 예외처리"
      sap:VirtualizedContainerService.HintSize="900,500"
      sap2010:WorkflowViewState.IdRef="TryCatch_1">
      <TryCatch.Try>
        <Sequence DisplayName="메인 처리 로직"
          sap:VirtualizedContainerService.HintSize="870,400"
          sap2010:WorkflowViewState.IdRef="Sequence_Try">
{main_xml}
        </Sequence>
      </TryCatch.Try>
      <TryCatch.Catches>
        <Catch x:TypeArguments="s:Exception"
          xmlns:s="clr-namespace:System;assembly=mscorlib">
          <ActivityAction x:TypeArguments="s:Exception"
            xmlns:s="clr-namespace:System;assembly=mscorlib">
            <ActivityAction.Argument>
              <DelegateInArgument x:TypeArguments="s:Exception"
                xmlns:s="clr-namespace:System;assembly=mscorlib"
                Name="exception" />
            </ActivityAction.Argument>
            <Sequence DisplayName="오류 처리"
              sap:VirtualizedContainerService.HintSize="870,200"
              sap2010:WorkflowViewState.IdRef="Sequence_Catch">
{error_xml}
            </Sequence>
          </ActivityAction>
        </Catch>
      </TryCatch.Catches>
    </TryCatch>
  </Sequence>
</Activity>"""


def build_project_json(process_name: str, display_name: str) -> str:
    project = {
        "name": re.sub(r'[^\w가-힣]', '', process_name.replace(" ", "_")),
        "projectId": str(uuid.uuid4()),
        "description": display_name,
        "main": "Main.xaml",
        "dependencies": {
            "UiPath.Excel.Activities": "[3.1.2]",
            "UiPath.Mail.Activities": "[2.7.12]",
            "UiPath.System.Activities": "[25.10.4]",
            "UiPath.UIAutomation.Activities": "[25.10.4]"
        },
        "schemaVersion": "4.0",
        "studioVersion": "24.10.9.0",
        "projectVersion": "1.0.0",
        "expressionLanguage": "VisualBasic",
        "targetFramework": "Windows",
        "runtimeOptions": {
            "autoDispose": False,
            "isPausable": True,
            "requiresUserInteraction": True,
            "supportsPersistence": False,
        },
        "designOptions": {
            "outputType": "Process",
            "libraryOptions": {"includeOriginalXaml": False, "privateWorkflows": []},
            "processOptions": {"ignoredFiles": []},
        },
        "entryPoints": [{"filePath": "Main.xaml", "uniqueId": str(uuid.uuid4()), "input": [], "output": []}],
        "isTemplate": False,
        "publishData": {},
        "createdOn": datetime.now().isoformat(),
        "generatedBy": "RPA Auto Doc & Development AI (LNLLAB)"
    }
    return json.dumps(project, ensure_ascii=False, indent=2)


def build_zip(process_name: str, xaml_content: str, project_json: str) -> bytes:
    safe = re.sub(r'[^\w가-힣]', '', process_name.replace(" ", "_"))
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(f"{safe}/Main.xaml", xaml_content)
        zf.writestr(f"{safe}/project.json", project_json)
        zf.writestr(f"{safe}/.screenshots/.gitkeep", "")
        zf.writestr(f"{safe}/.local/.gitkeep", "")
    buf.seek(0)
    return buf.read()


def call_claude(api_key: str, messages: list) -> tuple[str, str, dict]:
    """Claude API 호출 → (텍스트, msg_type, json_data)"""
    client = anthropic.Anthropic(api_key=api_key)
    api_messages = [{"role": m["role"], "content": m["content"]} for m in messages if m["role"] in ("user", "assistant")]
    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=4096,
        system=SYSTEM_PROMPT,
        messages=api_messages,
    )
    text = response.content[0].text

    if "[QUESTION]" in text:
        raw = text.split("[QUESTION]")[1].split("[/QUESTION]")[0].strip()
        try:
            data = json.loads(raw)
            return data.get("question", raw), "question", data.get("partial", {})
        except:
            return raw, "question", {}

    elif "[DONE]" in text:
        raw = text.split("[DONE]")[1].split("[/DONE]")[0].strip()
        try:
            data = json.loads(raw)
            return raw, "done", data
        except Exception as e:
            return f"JSON 파싱 오류: {e}\n\n{raw}", "error", {}

    return text, "generating", {}


# ============================================================
# Streamlit UI
# ============================================================
st.set_page_config(page_title="RPA Process Designer AI", page_icon="⚡", layout="wide", initial_sidebar_state="expanded")

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@300;400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap');
:root {
    --blue: #2563eb; --blue-pale: #eff6ff; --green: #059669; --green-pale: #ecfdf5;
    --gray-50: #f8fafc; --gray-200: #e2e8f0; --gray-500: #64748b;
    --gray-800: #1e293b; --gray-900: #0f172a; --radius: 12px; --radius-sm: 8px;
}
.stApp { font-family: 'Noto Sans KR', sans-serif; background: var(--gray-50); }
#MainMenu, header, footer { visibility: hidden; }
.block-container { padding-top: 1.5rem; }
[data-testid="stSidebar"] { background: linear-gradient(175deg, var(--gray-900) 0%, var(--gray-800) 100%); }
[data-testid="stSidebar"] * { color: #cbd5e1 !important; }
.header-banner {
    background: linear-gradient(135deg, var(--gray-900) 0%, #1e3a5f 60%, var(--blue) 100%);
    padding: 2rem 2.5rem; border-radius: var(--radius); margin-bottom: 1.5rem;
}
.header-banner h1 { color: white; font-size: 1.65rem; font-weight: 700; margin: 0 0 0.35rem 0; }
.header-banner p { color: rgba(255,255,255,0.7); font-size: 0.9rem; margin: 0; }
.header-badge {
    display: inline-block; background: rgba(59,130,246,0.25);
    border: 1px solid rgba(59,130,246,0.35); color: #93c5fd;
    padding: 0.2rem 0.7rem; border-radius: 20px; font-size: 0.72rem;
    font-weight: 600; margin-bottom: 0.75rem;
}
.stButton > button { border-radius: var(--radius-sm); font-weight: 600; }
.stTextArea textarea { border-radius: var(--radius-sm); font-size: 0.92rem; line-height: 1.7; }
</style>
""", unsafe_allow_html=True)

# 세션 초기화
defaults = {
    "step": 1, "definition": "", "chat_messages": [],
    "design_json": None, "xaml_output": None, "processing": False,
    "design_ready": False, "api_error_count": 0,
}
for k, v in defaults.items():
    if k not in st.session_state:
        st.session_state[k] = v

TEMPLATES = {
    "hr_onboard": {
        "icon": "👤", "name": "신규 입사자 온보딩",
        "desc": "입사자 계정 생성 자동화",
        "content": """프로세스명: NewEmployee_Onboarding

1. HR 시스템에서 신규 입사자 목록을 조회한다.
2. 입사 예정자가 없으면 프로세스를 종료한다.
3. 각 입사자에 대해 다음을 처리한다:
   - Active Directory에 계정을 생성한다.
   - 이메일 계정을 생성한다.
   - 부서에 따라 권한을 부여한다.
   - VPN 계정을 생성한다.
4. 계정 생성 완료 상태를 HR 시스템에 업데이트한다.
5. 오류 발생 시 IT 헬프데스크에 알림을 보낸다."""
    },
    "sales_report": {
        "icon": "📊", "name": "매출 보고 자동화",
        "desc": "SAP 매출 데이터 추출 및 보고",
        "content": """프로세스명: SalesReport_Auto

1. SAP 시스템에 로그인한다.
2. 전일 매출 데이터를 조회하여 Excel로 다운로드한다.
3. 각 매출 건에 대해 금액별로 분류한다:
   - 1억 이상: 대형거래 시트
   - 1000만 이상: 중형거래 시트
   - 그 외: 소형거래 시트
4. 대형거래가 있으면 팀장에게 이메일을 발송한다.
5. 결과 파일을 공유 폴더에 저장한다.
6. 오류 발생 시 담당자에게 알림을 보낸다."""
    },
    "leave_request": {
        "icon": "📅", "name": "휴가 신청 자동 처리",
        "desc": "휴가 신청서 작성 및 결재 제출",
        "content": """프로세스명: LeaveRequest_AutoSubmit

1. 사원 정보 시스템에 로그인한다.
2. 휴가 신청서 작성 화면으로 이동한다.
3. 다음 항목을 입력한다:
   - 휴가 유형 (연차/반차/병가)
   - 시작일과 종료일
   - 사유
4. 잔여 휴가일수를 확인한다.
   - 잔여일수 부족 시 신청을 중단하고 알림을 표시한다.
5. 신청서를 저장하고 결재 라인에 제출한다.
6. 신청자 이메일로 접수 확인 메일을 발송한다.
7. 오류 발생 시 담당자에게 알림을 보낸다."""
    },
}

# ============================================================
# SIDEBAR
# ============================================================
with st.sidebar:
    st.markdown("""
    <div style="padding:0.5rem 0 1rem 0;">
        <div style="font-size:1.3rem;font-weight:700;color:#f1f5f9!important;">⚡ RPA Designer AI</div>
        <div style="font-size:0.78rem;color:#94a3b8!important;margin-top:0.2rem;">LNLLAB · AX Challenge 2026</div>
    </div>""", unsafe_allow_html=True)
    st.markdown("---")

    pipe_steps = [("1","프로세스 정의서 입력","자연어로 입력"),("2","AI 설계 분석","JSON 구조 추출"),("3","XAML 생성 & 다운로드","검증된 템플릿으로 조립")]
    for num, label, sub in pipe_steps:
        n = int(num)
        if n < st.session_state.step: state, dot, icon = "done", "done", "✓"
        elif n == st.session_state.step: state, dot, icon = "active", "active", num
        else: state, dot, icon = "", "waiting", num
        dot_color = {"done":"#059669","active":"#2563eb","waiting":"#334155"}[dot]
        st.markdown(f"""
        <div style="display:flex;align-items:flex-start;gap:0.75rem;padding:0.7rem 0.85rem;border-radius:8px;margin-bottom:0.35rem;background:{'rgba(37,99,235,0.15)' if state=='active' else 'rgba(5,150,105,0.1)' if state=='done' else 'transparent'}">
            <div style="width:28px;height:28px;min-width:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:0.75rem;font-weight:700;background:{dot_color};color:white;">{icon}</div>
            <div>
                <div style="font-size:0.85rem;font-weight:500;color:#f1f5f9!important;">{label}</div>
                <div style="font-size:0.72rem;color:#64748b!important;">{sub}</div>
            </div>
        </div>""", unsafe_allow_html=True)

    st.markdown("---")
    api_key = st.text_input("Claude API Key", type="password", placeholder="sk-ant-...", key="api_key_input")
    st.markdown(f"""<div style="margin-top:0.5rem;font-size:0.85rem;">{"🟢 API 연결됨" if api_key else "🔴 API 키 필요"}</div>""", unsafe_allow_html=True)
    st.markdown("---")
    if st.button("🔄 새로 시작", use_container_width=True):
        for k, v in defaults.items():
            st.session_state[k] = v
        st.rerun()

# ============================================================
# HEADER
# ============================================================
st.markdown("""
<div class="header-banner">
    <div class="header-badge">TRACK 2 · RPA + AI</div>
    <h1>RPA Process Designer AI</h1>
    <p>자연어 → AI 설계 분석 → 검증된 템플릿으로 XAML 자동 조립</p>
</div>""", unsafe_allow_html=True)

# ============================================================
# STEP 1: 정의서 입력
# ============================================================
if st.session_state.step == 1:
    col_main, col_side = st.columns([2, 1])
    with col_main:
        st.markdown("#### 📋 템플릿으로 빠르게 시작하기")
        cols = st.columns(3)
        for i, (key, tpl) in enumerate(TEMPLATES.items()):
            with cols[i]:
                if st.button(f"{tpl['icon']} {tpl['name']}", key=f"tpl_{key}", use_container_width=True):
                    st.session_state.definition = tpl["content"]
                    st.rerun()

        # ── 파일 업로드 먼저 처리 (텍스트 영역 value 세팅 전에 실행되어야 함)
        uploaded = st.file_uploader(
            "📎 파일로 업로드 (txt, docx, pdf)",
            type=["txt", "docx", "pdf"],
            help="텍스트 파일, Word 문서, PDF 파일을 업로드할 수 있습니다.",
        )
        if uploaded:
            try:
                file_content = None
                if uploaded.type == "text/plain":
                    file_content = uploaded.read().decode("utf-8")
                elif uploaded.name.endswith(".docx"):
                    try:
                        import docx as docxlib
                        doc = docxlib.Document(uploaded)
                        file_content = "\n".join([p.text for p in doc.paragraphs if p.text.strip()])
                    except ImportError:
                        st.warning("⚠️ docx 파싱을 위해 `pip install python-docx` 가 필요합니다.")
                elif uploaded.type == "application/pdf":
                    try:
                        import pdfplumber
                        with pdfplumber.open(uploaded) as pdf:
                            file_content = "\n".join([p.extract_text() or "" for p in pdf.pages])
                    except ImportError:
                        st.warning("⚠️ PDF 파싱을 위해 `pip install pdfplumber` 가 필요합니다.")
                if file_content:
                    st.session_state.definition = file_content
                    st.success(f"📄 **{uploaded.name}** 업로드 완료")
            except Exception as e:
                st.error(f"파일 읽기 오류: {e}")

        st.markdown("")
        # ── 텍스트 영역: 파일 업로드 처리 후 세션값 기준으로 표시
        definition = st.text_area(
            "프로세스 정의서",
            value=st.session_state.definition,
            height=320,
            placeholder="프로세스명: OO 자동화\n\n1. 시스템에 로그인한다.\n2. 데이터를 조회한다.\n...",
            label_visibility="collapsed",
        )
        # 파일이 없을 때만 텍스트 영역 직접 수정값을 세션에 반영
        # (파일 업로드 시 텍스트 영역이 아직 이전값이므로 덮어쓰면 안됨)
        if not uploaded:
            st.session_state.definition = definition

        st.markdown("")
        col_btn1, col_btn2, _ = st.columns([1, 1, 2])
        with col_btn1:
            if st.button("🚀 AI 설계 시작", type="primary", use_container_width=True, disabled=not st.session_state.definition.strip()):
                st.session_state.step = 2
                st.session_state.chat_messages = []
                st.session_state.design_ready = False
                st.rerun()
        with col_btn2:
            if st.button("초기화", use_container_width=True):
                st.session_state.definition = ""
                st.rerun()

    with col_side:
        st.markdown("""
        <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:8px;padding:1rem;font-size:0.85rem;color:#334155;line-height:1.7;">
            <strong>💡 작성 팁</strong><br><br>
            단계별로 번호를 붙여 작성하면 AI가 더 정확하게 분석합니다.<br><br>
            "~이면", "각 항목에 대해" 같은 표현이 조건/반복으로 변환됩니다.<br><br>
            "오류 발생 시" 표현이 예외처리로 변환됩니다.
        </div>""", unsafe_allow_html=True)

# ============================================================
# STEP 2: AI 설계 분석 (JSON 추출)
# ============================================================
elif st.session_state.step == 2:
    api_key = st.session_state.get("api_key_input", "")

    st.markdown("#### ⚙️ Step 2. AI 설계 분석 중")
    st.caption("Claude가 프로세스를 분석하고 구조를 설계합니다. 모호한 부분은 질문합니다.")

    if not api_key:
        st.warning("⚠️ 사이드바에 Claude API 키를 먼저 입력해 주세요.")
    else:
        # 첫 진입 시 API 호출
        if not st.session_state.chat_messages:
            first_msg = f"다음 프로세스 정의서를 분석하여 JSON 설계를 만들어 주세요.\n\n{st.session_state.definition}"
            st.session_state.chat_messages.append({"role": "user", "content": first_msg, "msg_type": "user_init"})
            with st.spinner("🔍 프로세스 분석 중..."):
                try:
                    text, msg_type, data = call_claude(api_key, st.session_state.chat_messages)
                    st.session_state.chat_messages.append({"role": "assistant", "content": text, "msg_type": msg_type})
                    if msg_type == "done":
                        st.session_state.design_json = data
                        st.session_state.design_ready = True
                except Exception as e:
                    st.error(f"API 오류: {e}")
                    st.session_state.chat_messages = []
            st.rerun()

        # 채팅 히스토리 출력
        for msg in st.session_state.chat_messages:
            if msg.get("msg_type") == "user_init":
                continue
            if msg["role"] == "assistant":
                icon = "❓" if msg.get("msg_type") == "question" else "✅"
                with st.chat_message("assistant", avatar=icon):
                    if msg.get("msg_type") == "done":
                        st.success("✅ 설계 완료! 아래 버튼을 눌러 XAML을 생성하세요.")
                        try:
                            st.json(json.loads(msg["content"]))
                        except:
                            st.code(msg["content"])
                    else:
                        st.markdown(msg["content"])
            else:
                with st.chat_message("user", avatar="👤"):
                    st.markdown(msg["content"])

        if st.session_state.design_ready:
            if st.button("➡️ XAML 생성하기", type="primary", use_container_width=True):
                st.session_state.step = 3
                st.rerun()
        else:
            user_input = st.chat_input("답변을 입력하세요...")
            if user_input:
                st.session_state.chat_messages.append({"role": "user", "content": user_input})
                with st.spinner("이어서 분석 중..."):
                    try:
                        text, msg_type, data = call_claude(api_key, st.session_state.chat_messages)
                        st.session_state.chat_messages.append({"role": "assistant", "content": text, "msg_type": msg_type})
                        if msg_type == "done":
                            st.session_state.design_json = data
                            st.session_state.design_ready = True
                    except Exception as e:
                        st.error(f"API 오류: {e}")
                st.rerun()

    if st.button("⬅️ 이전"):
        st.session_state.step = 1
        st.session_state.chat_messages = []
        st.rerun()

# ============================================================
# STEP 3: XAML 생성 & 다운로드
# ============================================================
elif st.session_state.step == 3:
    data = st.session_state.design_json
    if not data:
        st.error("설계 데이터가 없습니다. 다시 시작해 주세요.")
        if st.button("⬅️ 처음으로"):
            st.session_state.step = 1
            st.rerun()
    else:
        process_name = data.get("process_name", "MyProcess")
        display_name = data.get("display_name", process_name)

        # XAML 생성
        if not st.session_state.xaml_output:
            with st.spinner("🔨 XAML 조립 중..."):
                st.session_state.xaml_output = build_xaml(data)

        xaml = st.session_state.xaml_output
        proj_json = build_project_json(process_name, display_name)
        zip_data = build_zip(process_name, xaml, proj_json)

        safe_name = re.sub(r'[^\w가-힣]', '', process_name.replace(" ", "_"))

        st.markdown(f"#### 🎉 완료: {display_name}")
        st.success("Python 템플릿으로 XAML이 조립되었습니다. UiPath Studio에서 열어보세요.")

        # 메트릭
        steps = data.get("steps", [])
        args = data.get("arguments", [])
        variables = data.get("variables", [])

        def count_steps(step_list):
            total = 0
            for s in step_list:
                total += 1
                total += count_steps(s.get("then_steps", []))
                total += count_steps(s.get("else_steps", []))
                total += count_steps(s.get("body_steps", []))
            return total

        total_activities = count_steps(steps) + count_steps(data.get("error_steps", []))
        m1, m2, m3, m4 = st.columns(4)
        m1.metric("총 액티비티", f"{total_activities}개")
        m2.metric("변수", f"{len(variables)}개")
        m3.metric("인자", f"{len(args)}개")
        m4.metric("XAML 라인", f"{len(xaml.splitlines())}줄")

        st.markdown("")

        # 다운로드
        col1, col2 = st.columns(2)
        with col1:
            st.download_button(
                "⬇️ UiPath 프로젝트 ZIP 다운로드",
                data=zip_data,
                file_name=f"{safe_name}_uipath.zip",
                mime="application/zip",
                use_container_width=True,
                type="primary",
            )
        with col2:
            st.download_button(
                "⬇️ JSON 설계서 다운로드",
                data=json.dumps(data, ensure_ascii=False, indent=2),
                file_name=f"{safe_name}_design.json",
                mime="application/json",
                use_container_width=True,
            )

        st.markdown("---")

        # 탭
        tab1, tab2, tab3 = st.tabs(["📄 생성된 XAML", "📋 프로세스 설계서", "🗂 JSON 설계서"])

        with tab1:
            st.code(xaml, language="xml", line_numbers=True)

        with tab2:
            # 프로세스 설계 문서 자동 생성
            def render_steps_doc(step_list, indent=0):
                lines = []
                prefix = "  " * indent
                for i, s in enumerate(step_list, 1):
                    t = s.get("type", "")
                    dn = s.get("display_name", "")
                    type_label = {
                        "log": "📝 로그", "click": "🖱 클릭", "type": "⌨️ 입력",
                        "assign": "📌 변수할당", "if": "🔀 조건분기", "foreach": "🔁 반복"
                    }.get(t, t)
                    lines.append(f"{prefix}{i}. **{type_label}** — {dn}")
                    if t == "if":
                        lines.append(f"{prefix}   - 조건: `{s.get('condition', '')}`")
                        if s.get("then_steps"):
                            lines.append(f"{prefix}   - True:")
                            lines.extend(render_steps_doc(s["then_steps"], indent + 2))
                        if s.get("else_steps"):
                            lines.append(f"{prefix}   - False:")
                            lines.extend(render_steps_doc(s["else_steps"], indent + 2))
                    elif t == "foreach":
                        if s.get("body_steps"):
                            lines.append(f"{prefix}   - 반복 내용:")
                            lines.extend(render_steps_doc(s["body_steps"], indent + 2))
                return lines

            doc = f"""## {display_name}

---

### 📌 프로세스 개요

| 항목 | 내용 |
|------|------|
| 프로세스명 | {process_name} |
| 표시명 | {display_name} |
| 총 액티비티 | {total_activities}개 |
| 예외처리 | TryCatch 기본 적용 |

---

### 🔀 프로세스 흐름

{"".join([f'{chr(10)}{line}' for line in render_steps_doc(steps)])}

---

### 📋 인자 목록

| 이름 | 방향 | 타입 |
|------|------|------|
{"".join([f'| {a["name"]} | {a["direction"]} | {a["type"]} |{chr(10)}' for a in args]) if args else "| (없음) | - | - |"}

---

### 📦 변수 목록

| 이름 | 타입 | 기본값 |
|------|------|--------|
{"".join([f'| {v["name"]} | {v["type"]} | {v.get("default","")} |{chr(10)}' for v in variables]) if variables else "| (없음) | - | - |"}

---

### ⚠️ 예외처리

| 예외 유형 | 처리 방식 |
|-----------|-----------|
| System.Exception | 오류 로그 기록 후 프로세스 종료 |

---

### 📝 비고
- UI 자동화 액티비티(NClick, NTypeInto)는 UiPath Studio에서 Selector를 직접 지정해야 합니다.
- 생성일: {datetime.now().strftime("%Y-%m-%d %H:%M")}
- 생성 도구: RPA Auto Doc & Development AI (LNLLAB)
"""
            st.markdown(doc)
            st.download_button(
                "⬇️ 설계서 .md 다운로드",
                data=doc,
                file_name=f"{safe_name}_설계서.md",
                mime="text/markdown",
                use_container_width=True,
            )

        with tab3:
            st.json(data)

        st.markdown("")
        col_r1, col_r2, _ = st.columns([1, 1, 2])
        with col_r1:
            if st.button("⬅️ 설계 다시 보기", use_container_width=True):
                st.session_state.step = 2
                st.session_state.xaml_output = None
                st.rerun()
        with col_r2:
            if st.button("🔄 새 프로세스 시작", type="primary", use_container_width=True):
                for k, v in defaults.items():
                    st.session_state[k] = v
                st.rerun()

# FOOTER
st.markdown("---")
st.markdown("""
<div style="text-align:center;padding:1rem 0 0.5rem 0;font-size:0.78rem;color:#94a3b8;">
    ⚡ RPA Process Designer AI · LNLLAB · CocoaSoft AX Challenge 2026
</div>""", unsafe_allow_html=True)
